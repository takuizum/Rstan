library(gamlss.dist)

set.seed(123)

ZIP_rng <- rZIP(n=10, mu=6, sigma=0.5)
#=> [1] 0 6 0 8 9 0 2 8 3 0