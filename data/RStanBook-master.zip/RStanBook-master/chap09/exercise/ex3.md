以下の2通りある.

* dot_product関数
* real operator*(row_vector x, vector y)
