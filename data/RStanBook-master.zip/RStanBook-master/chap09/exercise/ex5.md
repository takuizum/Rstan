以下の通り.

* real fmin(real x, real y)
* int min(int x, int y)
* int min(int x[])
* real min(matrix x)
* real min(real x[])
* real min(row_vector x)
* real min(vector x)